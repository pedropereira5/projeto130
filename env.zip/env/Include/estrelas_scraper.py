import time
import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver

# Configuração do webdriver (coloque o caminho para o seu driver do navegador)
driver_path = "caminho/para/o/seu/driver"
driver = webdriver.Chrome(executable_path=driver_path)

# URL da página com os dados das estrelas anãs marrons
url = "https://pt.wikipedia.org/wiki/An%C3%A3_marrom"

# Abre a página usando o webdriver
driver.get(url)

# Aguarde um curto período para que a página seja totalmente carregada
time.sleep(2)

# Obtém o conteúdo HTML da página
html_content = driver.page_source

# Fechar o webdriver após obter o conteúdo HTML
driver.quit()

# Criar o objeto BeautifulSoup
soup = BeautifulSoup(html_content, "html.parser")

# Encontra a tabela com a classe "wikitable"
table = soup.find("table", class_="wikitable")

# Encontra todas as linhas de dados (tags <tr>) da tabela
rows = table.find_all("tr")

# Lista para armazenar os dados coletados
scraped_data = []

# Loop através das linhas e extrair os dados das colunas
for row in rows[1:]:
    columns = row.find_all("td")

    # Extrair os dados das colunas
    name = columns[0].text.strip()
    distance = columns[1].text.strip()
    mass = columns[2].text.strip()
    radius = columns[3].text.strip()
    luminosity = columns[4].text.strip()

    # Adicionar os dados da estrela na lista scraped_data
    temp_list = [name, distance, mass, radius, luminosity]
    scraped_data.append(temp_list)

# Criar o dataframe usando pandas
stars_data = pd.DataFrame(scraped_data, columns=["Nome da estrela", "Distância", "Massa", "Raio", "Luminosidade"])

# Exportar o dataframe para um arquivo CSV
stars_data.to_csv("estrelas_anas_marrons.csv", index=False)

import requests
from bs4 import BeautifulSoup

# URL da página com os dados das estrelas anãs marrons
url = "https://pt.wikipedia.org/wiki/An%C3%A3_marrom"

# Faz uma requisição da página usando o módulo requests
response = requests.get(url)

# Verifica se a requisição foi bem-sucedida
if response.status_code == 200:
    # Obtém o conteúdo HTML da página
    html_content = response.text
else:
    print(f"Erro na requisição. Status code: {response.status_code}")
    exit()

# Criar o objeto BeautifulSoup
soup = BeautifulSoup(html_content, "html.parser")

# Encontra todas as tabelas da página usando o método find_all
all_tables = soup.find_all("table")

# Criar uma lista para armazenar as tabelas
tables_data = []

# Loop através das tabelas e obter os dados das linhas (tags <tr>)
for table in all_tables:
    rows = table.find_all("tr")
    table_data = []
    
    # Loop através das linhas e extrair os dados das colunas
    for row in rows:
        columns = row.find_all("td")
        row_data = [column.text.strip() for column in columns]
        table_data.append(row_data)
    
    tables_data.append(table_data)

# Imprimir as tabelas
for i, table_data in enumerate(tables_data, 1):
    print(f"=== Tabela {i} ===")
    for row_data in table_data:
        print(row_data)
    print("\n")
# Lista para armazenar todas as tags <td>
td_tags = []

# Loop for para extrair todas as tags <td>
for table_data in tables_data:
    for row_data in table_data:
        for data in row_data:
            td_tags.append(data.strip())

# Criar listas vazias para armazenar os dados
nomes_estrelas = []
distancias = []
massas = []
raios = []

# Loop na lista de tags <td> para obter os dados do nome da estrela, raio, massa e distância
for i in range(0, len(td_tags), 5):  # Incremento de 5 pois cada linha tem 5 colunas
    nomes_estrelas.append(td_tags[i])
    distancias.append(td_tags[i + 1])
    massas.append(td_tags[i + 2])
    raios.append(td_tags[i + 3])

# Usando a biblioteca pandas, criar um DataFrame a partir das listas acima
data = {
    "Nome da estrela": nomes_estrelas,
    "Distância": distancias,
    "Massa": massas,
    "Raio": raios
}

df = pd.DataFrame(data)

# Salvar o DataFrame em um arquivo CSV
df.to_csv("estrelas_anas_marrons.csv", index=False)

import pandas as pd

# Ler o arquivo CSV do projeto 127
data1 = pd.read_csv("estrelas_data.csv")

# Ler o arquivo CSV do projeto 128
data2 = pd.read_csv("estrelas_anas_marrons.csv")

# Mesclar os DataFrames usando o método merge do pandas
merged_data = data1.merge(data2, on="Nome da estrela", how="inner")

# Salvar o DataFrame mesclado em um novo arquivo CSV
merged_data.to_csv("estrelas_mescladas.csv", index=False)

import pandas as pd

# Carregar o arquivo CSV das estrelas anãs marrons
data_anas_marrons = pd.read_csv("estrelas_anas_marrons.csv")

# Limpar os dados excluindo valores NAN
data_anas_marrons_cleaned = data_anas_marrons.dropna()

# Verificar o DataFrame após a limpeza
print(data_anas_marrons_cleaned)

# Converter as colunas massa e raio para valores de ponto flutuante
data_anas_marrons_cleaned["Massa"] = data_anas_marrons_cleaned["Massa"].astype(float)
data_anas_marrons_cleaned["Raio"] = data_anas_marrons_cleaned["Raio"].astype(float)

# Verificar o DataFrame após a conversão
print(data_anas_marrons_cleaned)

# Multiplicar cada valor da coluna raio por 0.102763 para converter para o raio solar
data_anas_marrons_cleaned["Raio"] = data_anas_marrons_cleaned["Raio"] * 0.102763

# Multiplicar cada valor da coluna massa por 0.000954588 para converter para a massa solar
data_anas_marrons_cleaned["Massa"] = data_anas_marrons_cleaned["Massa"] * 0.000954588

# Verificar o DataFrame após as conversões
print(data_anas_marrons_cleaned)

# Criar um novo arquivo CSV com os dados limpos e convertidos das estrelas anãs marrons
data_anas_marrons_cleaned.to_csv("estrelas_anas_marrons_cleaned.csv", index=False)

# Ler o arquivo CSV das estrelas mais brilhantes
data_estrelas_mais_brilhantes = pd.read_csv("estrelas_data.csv")

# Mesclar os dois DataFrames usando o método merge do pandas
data_mesclada = data_estrelas_mais_brilhantes.merge(data_anas_marrons_cleaned, on="Star_name", how="inner")

# Salvar o DataFrame mesclado em um novo arquivo CSV
data_mesclada.to_csv("estrelas_mescladas.csv", index=False)

import pandas as pd

# Importar o arquivo CSV mesclado do projeto anterior
data_mesclada = pd.read_csv("estrelas_mescladas.csv")

# Converter o arquivo em um DataFrame
df = pd.DataFrame(data_mesclada)

# Imprimir o DataFrame
print(df)

# Listar todas as colunas do DataFrame
print(df.columns)

# Excluir as colunas não necessárias
df = df.drop(columns=["Luminosidade"])

# Excluir os valores NAN dos dados
df = df.dropna()

# Imprimir o DataFrame após a exclusão das colunas e valores NAN
print(df)

# Usar o método describe() para verificar detalhes estatísticos do DataFrame
print(df.describe())

# Usar o método info() para obter informações sobre o DataFrame
print(df.info())

# Usar o atributo dtypes para verificar os tipos de dados das colunas
print(df.dtypes)

# Salvar o DataFrame como um arquivo CSV chamado "final_data.csv"
df.to_csv("final_data.csv", index=False)

# Baixar o arquivo "final_data.csv"
from google.colab import files

files.download("final_data.csv")
